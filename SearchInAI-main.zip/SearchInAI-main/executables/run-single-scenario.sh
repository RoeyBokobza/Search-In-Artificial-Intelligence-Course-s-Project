#!/bin/bash

../build/bin/run-single-scenario ../maze-32-32-2/maze-32-32-2.map ../maze-32-32-2/scen-random/maze-32-32-2-random-1.scen 10