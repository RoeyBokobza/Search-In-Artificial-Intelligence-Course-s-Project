#!/bin/bash

../build/bin/run-experiments ../room-64-64-8/room-64-64-8.map ../room-64-64-8/scen-random ../outputs/